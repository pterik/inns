<?php
$mosConfig_absolute_path = 'D:/WEBDEV/xampp/htdocs/joomla';

if ($dir = opendir ( $GLOBALS['mosConfig_absolute_path'] . "/components/com_ezrealty/forms/list_templates" )) {
		while ( ($file = readdir ( $dir )) !== false ) {
		    echo "filename: $file : filetype: " . filetype($dir . $file) . "\n";
				if ($file != ".." && $file != ".") {
				if(is_dir($mosConfig_absolute_path."/components/com_ezrealty/forms/list_templates"."/".$file)) {
					if(!($file[0] == '.')) {
					    echo  'afdfs';
						$filelist[] = $file;
					}
				}
			}
		}
		closedir ( $dir );
	}
?>