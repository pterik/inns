<?php

#############################################################################
#                                                                           #
#  EZ Realty 4.0.0 - A Joomla/Mambo Real Estate component                   #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################

//Don't allow direct linking
  defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


    /**************************************************\
            THIS IS A DUMMY FILE - LEAVE IT HERE
    \**************************************************/

?>