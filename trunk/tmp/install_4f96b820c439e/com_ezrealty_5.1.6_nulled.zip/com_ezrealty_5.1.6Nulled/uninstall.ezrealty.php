<?php

#############################################################################
#                                                                           #
#  EZ Realty 5.0.0 - A Mambo Real Estate component                          #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


function com_uninstall()

{

echo "EZ Realty has been uninstalled.  You may now want to remove the image directories.";

}



?>