<?php

/**
* FileName: mod_ezrealty_quicksearch.php
* Date: 16-02-2008
* License: Commercial copyright
* Script Version #: 1.4
* EZ Realty Version #: 5.1.0 stable
* Author: K.J. Strickland - http://www.raptorservices.com.au
**/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

# call some core configuration variables:
global $mainframe, $mosConfig_lang;

# Get the right language file

DEFINE("LANGUAGE_PATH7","modules/mod_ezrealty_quicksearch/mod_ezrealty_quicksearch");

if (file_exists(LANGUAGE_PATH7."/".$mosConfig_lang.".php")) {
  include(LANGUAGE_PATH7."/".$mosConfig_lang.".php");
} elseif (file_exists(LANGUAGE_PATH7."/english.php"))  {
  include(LANGUAGE_PATH7."/english.php");
} else {
echo "Language file is not available";
}

DEFINE("EZADMIN_PATH7","administrator/components/com_ezrealty");

if (file_exists(EZADMIN_PATH7."/config.ezrealty.php")) {
  include(EZADMIN_PATH7."/config.ezrealty.php");
} else {
echo 'Configuration file not available';
}


$moduleclass_sfx    = $params->get( 'moduleclass_sfx' );
$orientation 	= $params->get( 'orientation' ) ;


  # Build property type select list

  	$typeit[] = mosHTML::makeOption( 0, _EZREALTY_LISTING_ANYTYPE3 );
if ( $er_usetype1 ) {
  	$typeit[] = mosHTML::makeOption( 1, _EZREALTY_TYPE_SALE3 );
  }
if ( $er_usetype2 ) {
  	$typeit[] = mosHTML::makeOption( 2, _EZREALTY_TYPE_RENTAL3 );
  }
if ( $er_usetype3 ) {
  	$typeit[] = mosHTML::makeOption( 3, _EZREALTY_TYPE_LEASE3 );
  }
if ( $er_usetype4 ) {
  	$typeit[] = mosHTML::makeOption( 4, _EZREALTY_TYPE_AUCTION3 );
  }
if ( $er_usetype5 ) {
  	$typeit[] = mosHTML::makeOption( 5, _EZREALTY_TYPE_SWAP3 );
  }
if ( $er_usetype6 ) {
  	$typeit[] = mosHTML::makeOption( 6, _EZREALTY_TYPE_TENDER3 );
  }
  
  	$lists['type'] = mosHTML::selectList( $typeit, 'type', 'class="searchbox2" size="1"' , 'value', 'text', '' );

  # Build Min Price select list

	$sql	= "SELECT a.range as value, a.display as text FROM #__ezrealty_price AS a WHERE a.published=1 ORDER by ordering";
	$database->setQuery($sql);
	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$maxpriceit[] = mosHTML::makeOption( '', _EZREALTY_MAXPRICE3 );
	$maxpriceit = array_merge( $maxpriceit, $database->loadObjectList() );
	$lists['maxprice'] = mosHTML::selectList( $maxpriceit, 'maxprice', 'class="searchbox2" size="1"','value', 'text', '');


  # Build Locality select list

	$sql	= "SELECT locid as value, ezcity as text FROM #__ezrealty_locality ORDER by ezcity";
	$database->setQuery($sql);
	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$ezcitylist[] = mosHTML::makeOption( '0', _EZREALTY_SEARCH_ALLOC3 );
	$ezcitylist = array_merge( $ezcitylist, $database->loadObjectList() );
	$lists['locid5'] = mosHTML::selectList( $ezcitylist, 'locid5', 'class="searchbox2" size="1"','value', 'text', '');


// Find EZ Realty Itemid from the menu table

	$query = "SELECT * from #__menu"
	. "\n WHERE link = 'index.php?option=com_ezrealty'"
	;
	$database->setQuery( $query );
	$id = $database->loadResult();
	$Itemid = $id;

?>



	<form name="searchfilter" action="<?php echo sefRelToAbs("index.php?option=com_ezrealty&amp;Itemid=$Itemid&amp;task=quickresults");?>" method="post">
	<input type="hidden" name="option" value="com_ezrealty" />
	<input type="hidden" name="Itemid" value="<?php echo $Itemid;?>" />
	<input type="hidden" name="task" value="quickresults" />
	<input type="hidden" name="direction" value="ASCPRICE" />

<table class="moduletable<?php echo $moduleclass_sfx;?>">

<?php if ($orientation == 0) { ?>

	<tr>
		<td><?php echo $lists['type'];?></td>
	</tr>
	<tr>
		<td><?php echo $lists['locid5'];?></td>
	</tr>
	<tr>
		<td><?php echo $lists['maxprice'];?></td>
	</tr>
	<tr>
		<td><input class="button" type="submit" name="<?php echo _EZREALTY_SEARCH_SEARCH3;?>" value="<?php echo _EZREALTY_SEARCH_SEARCH3;?>" /></td>
	</tr>

<?php } else { ?>

	<tr>
		<td><?php echo $lists['type'];?> <?php echo $lists['locid5'];?> <?php echo $lists['maxprice'];?> <input class="button" type="submit" name="<?php echo _EZREALTY_SEARCH_SEARCH3;?>" value="<?php echo _EZREALTY_SEARCH_SEARCH3;?>" /></td>

	</tr>

<?php } ?>

</table>
	</form>
