<?php

#############################################################################
#                                                                           #
#  EZ Realty 5.0.0 - A Mambo Real Estate component                          #
#  EZ Realty QuickSearch Module Language File version 1.0                   #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
#  http://www.raptorservices.com.au                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################

    /**** LANGUAGE FILE INFO *****************\
    **
    **   English language
    **   By: K.J. Strickland (aka PixelBunyiP)
    **   http://www.raptorservices.com.au
    **
    **  
    \*****************************************/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


DEFINE("_EZREALTY_LISTING_ANYTYPE3","Angebotsart");
DEFINE("_EZREALTY_TYPE_SALE3","Verkauf");
DEFINE("_EZREALTY_TYPE_RENTAL3","Vermietung");
DEFINE("_EZREALTY_LISTING_TYPE3","Angebotsart");
DEFINE("_EZREALTY_SEARCHLOC3","Ort");
DEFINE("_EZREALTY_MINPRICE3","Min. Preis");
DEFINE("_EZREALTY_SEARCH_SEARCH3","Suche");
DEFINE("_EZREALTY_SEARCH_ALLOC3","W�hle alle Orte");

DEFINE("_EZREALTY_TYPE_LEASE3","For Lease");
DEFINE("_EZREALTY_TYPE_AUCTION3","For Auction");
DEFINE("_EZREALTY_TYPE_SWAP3","For Swap");





?>