<?php

#############################################################################
#                                                                           #
#  EZ Realty 5.0.0 - A Mambo Real Estate component                          #
#  EZ Realty QuickSearch Module Language File version 1.0                   #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
#  http://www.raptorservices.com.au                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################

    /**** LANGUAGE FILE INFO *****************\
    **   
    **   French language
    **   By: Frank Schroeder(aka Phoenix)
    **   http://www.darkgroup.net
    **  
    **  
    \*****************************************/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


DEFINE("_EZREALTY_LISTING_ANYTYPE3","Tout Type De Liste");
DEFINE("_EZREALTY_TYPE_SALE3","En Vente");
DEFINE("_EZREALTY_TYPE_RENTAL3","Pour Le Loyer");
DEFINE("_EZREALTY_LISTING_TYPE3","Type De Liste");
DEFINE("_EZREALTY_SEARCHLOC3","Ville");
DEFINE("_EZREALTY_MINPRICE3","Prix min.");
DEFINE("_EZREALTY_SEARCH_SEARCH3","Search");
DEFINE("_EZREALTY_SEARCH_ALLOC3","Tous");

DEFINE("_EZREALTY_TYPE_LEASE3","For Lease");
DEFINE("_EZREALTY_TYPE_AUCTION3","For Auction");
DEFINE("_EZREALTY_TYPE_SWAP3","For Swap");



?>