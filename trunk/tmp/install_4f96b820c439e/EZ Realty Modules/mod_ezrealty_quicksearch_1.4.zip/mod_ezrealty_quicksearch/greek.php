<?php

#############################################################################
#                                                                           #
#  EZ Realty 5.0.0 - A Mambo Real Estate component                          #
#  EZ Realty QuickSearch Module Language File version 1.0                   #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
#  http://www.raptorservices.com.au                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################

    /**** LANGUAGE FILE INFO *****************\
    **   
    **   greek language
    **   By: panagiotis kostoulidis
    **   http://www.virtualaggelies.com
    **  
    **  
    \*****************************************/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


DEFINE("_EZREALTY_LISTING_ANYTYPE3","Ολες οι Κατηγορίες Ακινήτων");
DEFINE("_EZREALTY_TYPE_SALE3","Προς Πώληση");
DEFINE("_EZREALTY_TYPE_RENTAL3","Προς Εκμίσθωση");
DEFINE("_EZREALTY_LISTING_TYPE3","Κατηγορία Ακινήτου");
DEFINE("_EZREALTY_SEARCHLOC3","Περιοχή");
DEFINE("_EZREALTY_SEARCH_SEARCH3","ΑΝΑΖΗΤΗΣΗ");
DEFINE("_EZREALTY_SEARCH_ALLOC3","Ολες οι Περιοχές");

DEFINE("_EZREALTY_TYPE_LEASE3","Για Leasing");
DEFINE("_EZREALTY_TYPE_AUCTION3","Για Πλειστηριασμό");
DEFINE("_EZREALTY_TYPE_TENDER3","Πώληση απο Αμεση Ανάγκη");

DEFINE("_EZREALTY_MAXPRICE3","ΤΙΜΗ Μεγαλύτερη");
DEFINE("_EZREALTY_TYPE_SWAP3","Ανταλλαγή Ακινήτων");


?>