<?php

#############################################################################
#                                                                           #
#  EZ Realty 5.0.0 - A Joomla/Mambo Real Estate component                   #
#  EZ Realty Menu Module Language File                                      #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
#  http://www.raptorservices.com.au                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################

    /**** LANGUAGE FILE INFO *****************\
    **   
    **   English language
    **   By: K.J. Strickland (aka PixelBunyiP)
    **   http://www.raptorservices.com.au
    **  
    \*****************************************/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


DEFINE("_EZREALTY_MENU_MODULE1","Property Listings");
DEFINE("_EZREALTY_MENU_MODULE2","Search Listings");
DEFINE("_EZREALTY_MENU_MODULE3","New Listings");
DEFINE("_EZREALTY_MENU_MODULE4","Open House Listings");
DEFINE("_EZREALTY_MENU_MODULE5","Featured Listings");
DEFINE("_EZREALTY_MENU_MODULE6","Properties Wanted");
DEFINE("_EZREALTY_MENU_MODULE7","Register Requirements");
DEFINE("_EZREALTY_MENU_MODULE8","Our Agents/Sellers");
DEFINE("_EZREALTY_MENU_MODULE9","My Short List");
DEFINE("_EZREALTY_MENU_MODULE10","My EZ Panel");



?>