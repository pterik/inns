<?php



#############################################################################

#                                                                           #

#  EZ Realty 5.0.0 - A Joomla/Mambo Real Estate component                   #

#  EZ Realty Menu Module Language File                                      #

#  By: Kathy Strickland (aka PixelBunyiP)                                   #

#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #

#  All rights reserved                                                      #

#  http://www.raptorservices.com.au                                         #

#  Released as a commercial component!                                      #

#                                                                           #

#############################################################################



    /**** LANGUAGE FILE INFO *****************\

    **   

    **   English language

    **   By: K.J. Strickland (aka PixelBunyiP)

    **   http://www.raptorservices.com.au

    **  

    \*****************************************/





defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );





DEFINE("_EZREALTY_MENU_MODULE1","Listas Im�veis");

DEFINE("_EZREALTY_MENU_MODULE2","");

DEFINE("_EZREALTY_MENU_MODULE3","Novas Listas");

DEFINE("_EZREALTY_MENU_MODULE5","Destaques");

DEFINE("_EZREALTY_MENU_MODULE6","Im�veis Procurados");

DEFINE("_EZREALTY_MENU_MODULE7","");

DEFINE("_EZREALTY_MENU_MODULE8","Agentes");

DEFINE("_EZREALTY_MENU_MODULE9","");








?>