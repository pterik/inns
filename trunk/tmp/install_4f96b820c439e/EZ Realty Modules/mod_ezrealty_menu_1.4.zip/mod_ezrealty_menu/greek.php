<?php

#############################################################################
#                                                                           #
#  EZ Realty 5.0.0 - A Joomla/Mambo Real Estate component                   #
#  EZ Realty Menu Module Language File                                      #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
#  http://www.raptorservices.com.au                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################

    /**** LANGUAGE FILE INFO *****************\
    **   
    **   greek language
    **   By: panagiotis kostoulidis
    **   http://www.virtualaggelies.com
    **  
    \*****************************************/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


DEFINE("_EZREALTY_MENU_MODULE1","Καταγραφές Ακινήτων");
DEFINE("_EZREALTY_MENU_MODULE2","Αναζήτηση Ακινήτων");
DEFINE("_EZREALTY_MENU_MODULE3","Νέες Καταγραφές Ακινήτων");
DEFINE("_EZREALTY_MENU_MODULE4","Ακίνητα Σε Open House");
DEFINE("_EZREALTY_MENU_MODULE5","Ιδιαίτερα Ακίνητα");
DEFINE("_EZREALTY_MENU_MODULE6","Ακίνητα με Μεγάλη Ζήτηση");
DEFINE("_EZREALTY_MENU_MODULE7","Προϋποθέσεις Εγγραφής");
DEFINE("_EZREALTY_MENU_MODULE8","Σύμβουλοι Ακινήτων/Μεσίτες");
DEFINE("_EZREALTY_MENU_MODULE9","ΛΙΣΤΑ");
DEFINE("_EZREALTY_MENU_MODULE10","ΚΑΤΗΓΟΡΙΕΣ");



?>