<?php

/**
* FileName: mod_ezrealty_menu.php
* Date: 16-02-2008
* License: Commercial copyright
* Script Version #: 1.4
* EZ Realty Version #: 5.1.0 stable
* Author: K.J. Strickland - http://www.raptorservices.com.au
**/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

# call some core configuration variables:
global $mainframe, $mosConfig_lang;

# Get the right language file

DEFINE("LANGUAGE_PATH4","modules/mod_ezrealty_menu/mod_ezrealty_menu");

if (file_exists(LANGUAGE_PATH4."/".$mosConfig_lang.".php")) {
  include(LANGUAGE_PATH4."/".$mosConfig_lang.".php");
} elseif (file_exists(LANGUAGE_PATH4."/english.php"))  {
  include(LANGUAGE_PATH4."/english.php");
} else {
echo "Language file is not available";
}

DEFINE("EZADMIN_PATH4","administrator/components/com_ezrealty");

if (file_exists(EZADMIN_PATH4."/config.ezrealty.php")) {
  include(EZADMIN_PATH4."/config.ezrealty.php");
} else {
echo 'Configuration file not available';
}


$class_sfx = $params->get( 'class_sfx' ) ;
$moduleclass_sfx = $params->get( 'moduleclass_sfx' ) ;

// Find EZ Realty Itemid from the menu table

	$query = "SELECT * from #__menu"
	. "\n WHERE link = 'index.php?option=com_ezrealty'"
	;
	$database->setQuery( $query );
	$id = $database->loadResult();
	$Itemid = $id;

$link1b = sefRelToAbs( 'index.php?option=com_ezrealty&amp;Itemid='. $Itemid );
$link2b = sefRelToAbs( 'index.php?option=com_ezrealty&amp;task=search&amp;Itemid='. $Itemid );
$link3b = sefRelToAbs( 'index.php?option=com_ezrealty&amp;task=newlistings&amp;Itemid='. $Itemid );
$link4b = sefRelToAbs( 'index.php?option=com_ezrealty&amp;task=openhouse&amp;Itemid='. $Itemid );
$link5b = sefRelToAbs( 'index.php?option=com_ezrealty&amp;task=featured&amp;Itemid='. $Itemid );
$link6b = sefRelToAbs( 'index.php?option=com_ezrealty&amp;task=register&amp;Itemid='. $Itemid );
$link7b = sefRelToAbs( 'index.php?option=com_ezrealty&amp;task=displayprofiles&amp;Itemid='. $Itemid );
$link8b = sefRelToAbs( 'index.php?option=com_ezrealty&amp;task=ezpanel&amp;Itemid='. $Itemid );
$link9b = sefRelToAbs( 'index.php?option=com_ezrealty&amp;task=showleads&amp;Itemid='. $Itemid );
$link10b = sefRelToAbs( 'index.php?option=com_ezrealty&amp;task=viewlightbox&amp;Itemid='. $Itemid );

?>

<table class="moduletable<?php echo $moduleclass_sfx;?>" cellpadding="0" cellspacing="0" width="100%">

<tr><td><a href="<?php echo $link1b; ?>" class="<?php echo $class_sfx;?>"><?php echo _EZREALTY_MENU_MODULE1;?></a></td></tr>

	<?php if ( $er_searchlink ){ ?>
<tr><td><a href="<?php echo $link2b; ?>" class="<?php echo $class_sfx;?>"><?php echo _EZREALTY_MENU_MODULE2;?></a></td></tr>
	<?php } ?>

	<?php if ( $er_nllink ){ ?>
<tr><td><a href="<?php echo $link3b; ?>" class="<?php echo $class_sfx;?>"><?php echo _EZREALTY_MENU_MODULE3;?></a></td></tr>
	<?php } ?>

	<?php if ( $er_ohlink ){ ?>
<tr><td><a href="<?php echo $link4b; ?>" class="<?php echo $class_sfx;?>"><?php echo _EZREALTY_MENU_MODULE4;?></a></td></tr>
	<?php } ?>

	<?php if ( $er_featlink ){ ?>
<tr><td><a href="<?php echo $link5b; ?>" class="<?php echo $class_sfx;?>"><?php echo _EZREALTY_MENU_MODULE5;?></a></td></tr>
	<?php } ?>

	<?php if ( $er_reglead ){ ?>
<tr><td><a href="<?php echo $link9b; ?>" class="<?php echo $class_sfx;?>"><?php echo _EZREALTY_MENU_MODULE6;?></a></td></tr>
	<?php } ?>

	<?php if ( $er_reglead ){ ?>
<tr><td><a href="<?php echo $link6b; ?>" class="<?php echo $class_sfx;?>"><?php echo _EZREALTY_MENU_MODULE7;?></a></td></tr>
	<?php } ?>

	<?php if ( $er_useprofile && $er_showaglink ){ ?>
<tr><td><a href="<?php echo $link7b; ?>" class="<?php echo $class_sfx;?>"><?php echo _EZREALTY_MENU_MODULE8;?></a></td></tr>
	<?php } ?>
	<?php if ( $er_useshortlist ){ ?>
<tr><td><a href="<?php echo $link10b;?>" class="<?php echo $class_sfx;?>"><?php echo _EZREALTY_MENU_MODULE9;?></a></td></tr>
	<?php } ?>
	<?php if ( $er_memlink ){ ?>
<tr><td><a href="<?php echo $link8b; ?>" class="<?php echo $class_sfx;?>"><?php echo _EZREALTY_MENU_MODULE10;?></a></td></tr>
	<?php } ?>

</table>

