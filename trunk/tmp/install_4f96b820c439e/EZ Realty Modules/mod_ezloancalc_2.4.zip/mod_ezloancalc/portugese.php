<?php



#############################################################################

#                                                                           #

#  EZ LoanCalc Module Language File version 2.3                             #

#  By: Kathy Strickland (aka PixelBunyiP)                                   #

#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #

#  All rights reserved                                                      #

#  http://www.raptorservices.com.au                                         #

#  Released as a commercial component!                                      #

#                                                                           #

#############################################################################



    /**** LANGUAGE FILE INFO *****************\

    **   

    **   English language

    **   By: K.J. Strickland (aka PixelBunyiP)

    **   http://www.raptorservices.com.au

    **  

    \*****************************************/





defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );





DEFINE("_EZLOANCALC_INTRO","Quanto � que vai custar? Veja R�pido.");

DEFINE("_EZLOANCALC_AMOUNT","Quantia");

DEFINE("_EZLOANCALC_CURRENCY","�");

DEFINE("_EZLOANCALC_RATE","Taxa de Juro");

DEFINE("_EZLOANCALC_PERCENT","% por ano");

DEFINE("_EZLOANCALC_TERM","Dura��o");

DEFINE("_EZLOANCALC_YRS","Anos");

DEFINE("_EZLOANCALC_REPAY","Presta��es Mensais");

DEFINE("_EZLOANCALC_CALC","Calcular");

DEFINE("_EZLOANCALC_CLEAR","Limpar");





?>