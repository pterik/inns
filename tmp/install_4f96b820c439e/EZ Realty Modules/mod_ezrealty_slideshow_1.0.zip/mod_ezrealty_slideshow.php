<?php

/**
* FileName: mod_ezrealty_slideshow.php
* Date: 2-09-2007
* License: Commercial copyright
* Script Version #: 1.0
* EZ Realty Version #: 5.1.0 stable
* Author: K.J. Strickland - http://www.raptorservices.com.au
**/

/** The EZ Realty Slideshow has been built based on slideshow code by Alf Magne Kalleland **/

/***********************************************************************************************
* Copyright (c) 2005 - Alf Magne Kalleland post@dhtmlgoodies.com
* UPDATE LOG:
* March, 10th, 2006 : Added support for a message while large image is loading
* Get this and other scripts at www.dhtmlgoodies.com
* You can use this script freely as long as this copyright message is kept intact.
***********************************************************************************************/ 


/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

# Kill notices because people panic for no reason
error_reporting(E_ALL ^ E_NOTICE);

# call some core configuration variables:
global $mainframe;

DEFINE("EZADMIN_PATH10","administrator/components/com_ezrealty");

if (file_exists(EZADMIN_PATH10."/config.ezrealty.php")) {
  include(EZADMIN_PATH10."/config.ezrealty.php");
} else {
echo 'Configuration file not available';
}


$count 		= intval( $params->get( 'count', 5 ) );


// Find EZ Realty Itemid from the menu table

	$query = "SELECT * from #__menu"
	. "\n WHERE link = 'index.php?option=com_ezrealty'"
	;
	$database->setQuery( $query );
	$id = $database->loadResult();
	$Itemid = $id;

?>

<script type="text/javascript" src="<?php echo $mosConfig_live_site; ?>/modules/mod_ezrealty_slideshow/js/image-slideshow.js"></script>

<div id="ez_slideshow">
	<div id="galleryContainer">
		<div id="arrow_left"><img src="components/com_ezrealty/library/slideshow/images/arrow_left.gif" alt="" /></div>
		<div id="arrow_right"><img src="components/com_ezrealty/library/slideshow/images/arrow_right.gif" alt="" /></div>
		<div id="theImages">

<?php

if ( $er_expmgmt==1 ) {

if ( $er_expsys==0 ) {

	$query = "SELECT * FROM #__ezrealty WHERE published = 1 AND hits<$er_impnum AND image1 != '' ORDER BY id DESC LIMIT $count";
	$database->setQuery( $query );

} else {

$currentdate=mktime(0, 0, 0, date("m"), date("d"), date("Y"));

	$query = "SELECT * FROM #__ezrealty WHERE published = 1 AND expdate>$currentdate AND image1 != '' ORDER BY id DESC LIMIT $count";
	$database->setQuery( $query );

}

} else {

	$query = "SELECT * FROM #__ezrealty WHERE published = 1 AND image1 != '' ORDER BY id DESC LIMIT $count";
	$database->setQuery( $query );

}

	$rows = $database->loadObjectList();
	if ($database->getErrorNum()) {
		echo $database->stderr();
		return false;
	}

    $num_rows=ceil( count( $rows ) / 1 );
	if ($num_rows > 0) {

    $rowcounter = 0;
    foreach($rows as $row) {

?>

<a href="<?php echo sefRelToAbs("index.php?option=com_ezrealty&amp;Itemid=$Itemid&amp;task=detail&amp;id=$row->id");?>"><img src="components/com_ezrealty/<?php echo $er_imagedirectory;?>/th/<?php echo $row->image1;?>" alt="" /></a>


<?php


	}

}else{


}

?>

				<div id="slideEnd"></div>
		</div>
	</div>
</div>
