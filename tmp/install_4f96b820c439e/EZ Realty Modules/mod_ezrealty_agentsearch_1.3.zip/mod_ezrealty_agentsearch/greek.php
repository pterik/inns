<?php

#############################################################################
#                                                                           #
#  EZ Realty 5.0.0 - A Joomla/Mambo Real Estate component                   #
#  EZ REALTY AGENT SEARCH Module Language File version 1.1                  #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
#  http://www.raptorservices.com.au                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################

    /**** LANGUAGE FILE INFO *****************\
    **   
    **   greek language
    **   By: panagiotis kostoulidis
    **   http://www.virtualaggelies.com
    **  
    \*****************************************/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


DEFINE("_EZAGENTSEARCH_INTRO","Βρές Σύμβουλο Ακινήτων/Μεσίτη στην περιοχή σου");
DEFINE("_EZAGENTSEARCH_GO","ΑΝΑΖΗΤΗΣΗ");
DEFINE("_EZAGENTSEARCH_ALL","ΑΝΑΖΗΤΗΣΗ ΠΑΝΤΟΥ");


?>