<?php

/**
* FileName: mod_ezrealty_agentsearch.php
* Date: 16-02-2008
* License: Commercial copyright
* Script Version #: 1.3
* EZ Realty Version #: 5.1.0 stable
* Author: K.J. Strickland - http://www.raptorservices.com.au
**/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

# call some core configuration variables:
global $mainframe, $mosConfig_lang;

# Get the right language file

DEFINE("LANGUAGE_PATH1","modules/mod_ezrealty_agentsearch/mod_ezrealty_agentsearch");

if (file_exists(LANGUAGE_PATH1."/".$mosConfig_lang.".php")) {
  include(LANGUAGE_PATH1."/".$mosConfig_lang.".php");
} elseif (file_exists(LANGUAGE_PATH1."/english.php"))  {
  include(LANGUAGE_PATH1."/english.php");
} else {
echo "Language file is not available";
}

$moduleclass_sfx    = $params->get( 'moduleclass_sfx' );


  # Build Dealer Locality select list

	$sql	= "SELECT DISTINCT dealer_locality as value, dealer_locality as text FROM #__ezrealty_profile WHERE dealer_locality !='' ORDER by dealer_locality ASC";
	$database->setQuery($sql);

	$dlocalitylist[] = mosHTML::makeOption( '0', _EZAGENTSEARCH_ALL );
	$dlocalitylist = array_merge( $dlocalitylist, $database->loadObjectList() );
	$lists['dealerloc'] = mosHTML::selectList( $dlocalitylist, 'dealer_locality', 'class="searchbox2" size="1"','value', 'text', '');


// Find EZ Realty Itemid from the menu table

	$query = "SELECT * from #__menu"
	. "\n WHERE link = 'index.php?option=com_ezrealty'"
	;
	$database->setQuery( $query );
	$id = $database->loadResult();
	$Itemid = $id;

?>

<table class="moduletable<?php echo $moduleclass_sfx;?>">
	<tr>
		<td>

		<form name="dealersearchfilter" action="<?php echo sefRelToAbs("index.php?option=com_ezrealty&amp;Itemid=$Itemid&amp;task=dealerresults");?>" method="post">
		<input type="hidden" name="option" value="com_ezrealty" />
		<input type="hidden" name="Itemid" value="<?php echo $Itemid;?>" />
		<input type="hidden" name="task" value="dealerresults" />

		<div align="center">
			<table border="0">

				<tr>
					<td><strong><?php echo _EZAGENTSEARCH_INTRO;?>:-</strong><br /><?php echo $lists['dealerloc'];?>&nbsp;<input class="button" type="submit" name="<?php echo _EZAGENTSEARCH_GO;?>" value="<?php echo _EZAGENTSEARCH_GO;?>" /></td>
				</tr>
			</table>
		</div>

		</form>

		</td>
	</tr>
</table>
