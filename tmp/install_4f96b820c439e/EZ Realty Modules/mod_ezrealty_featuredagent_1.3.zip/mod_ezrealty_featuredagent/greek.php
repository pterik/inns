<?php

#############################################################################
#                                                                           #
#  EZ Realty Featured Agent Module                                          #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
#  http://www.raptorservices.com.au                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################

    /**** LANGUAGE FILE INFO *****************\
    **   
    **   English language
    **   By: panagiotis kostoulidis
    **   http://www.virtualaggelies.com
    **  
    \*****************************************/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


DEFINE("_MOD_EZREALTY_FAREADMORE","Δείτε Περισσότερα");

?>