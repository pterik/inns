<?php

/**
* FileName: mod_ezrealty_multifeatured.php
* Date: 16-02-2008
* License: Commercial copyright
* Script Version #: 1.6
* EZ Realty Version #: 5.1.0 stable
* Author: K.J. Strickland - http://www.raptorservices.com.au
**/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

# call some core configuration variables:
global $mainframe, $mosConfig_lang;

# Get the right language file

DEFINE("LANGUAGE_PATH5","modules/mod_ezrealty_multifeatured/mod_ezrealty_multifeatured");

if (file_exists(LANGUAGE_PATH5."/".$mosConfig_lang.".php")) {
  include(LANGUAGE_PATH5."/".$mosConfig_lang.".php");
} elseif (file_exists(LANGUAGE_PATH5."/english.php"))  {
  include(LANGUAGE_PATH5."/english.php");
} else {
echo "Language file is not available";
}

DEFINE("EZADMIN_PATH5","administrator/components/com_ezrealty");

if (file_exists(EZADMIN_PATH5."/config.ezrealty.php")) {
  include(EZADMIN_PATH5."/config.ezrealty.php");
} else {
echo 'Configuration file not available';
}

?>

<script type="text/JavaScript" src="includes/js/overlib_mini.js"></script>

<?php

$moduleclass_sfx    = $params->get( 'moduleclass_sfx' );
$count 		= intval( $params->get( 'count', 5 ) );
$horizspace = $params->get( 'horizspace' ) ;
$vertspace = $params->get( 'vertspace' ) ;
$colcount 	= $params->get( 'colcount' ) ;
$colwidth 	= $params->get( 'colwidth' ) ;
$align		= $params->get( 'align' ) ;
$slimbox4 	= $params->get( 'slimbox4' ) ;
$popwidth4 	= $params->get( 'popwidth4' ) ;


// Find EZ Realty Itemid from the menu table

	$query = "SELECT * from #__menu"
	. "\n WHERE link = 'index.php?option=com_ezrealty'"
	;
	$database->setQuery( $query );
	$id = $database->loadResult();
	$Itemid = $id;


echo '<table class="moduletable' . $moduleclass_sfx .'">';
echo '<tr>';


if ( $er_expmgmt==1 ) {

if ( $er_expsys==0 ) {

	$query = "SELECT * FROM #__ezrealty WHERE published = 1 AND featured = 1 AND hits<$er_impnum ORDER BY RAND() LIMIT $count";
	$database->setQuery( $query );

} else {

$currentdate=mktime(0, 0, 0, date("m"), date("d"), date("Y"));

	$query = "SELECT * FROM #__ezrealty WHERE published = 1 AND featured = 1 AND expdate>$currentdate ORDER BY RAND() LIMIT $count";
	$database->setQuery( $query );

}

} else {

	$query = "SELECT * FROM #__ezrealty WHERE published = 1 AND featured = 1 ORDER BY RAND() LIMIT $count";
	$database->setQuery( $query );

}

	$rows = $database->loadObjectList();
	if ($database->getErrorNum()) {
		echo $database->stderr();
		return false;
	}

    $num_rows=ceil( count( $rows ) / 1 );
	if ($num_rows > 0) {

    $rowcounter = 0;
    foreach($rows as $row) {
      if (($rowcounter%$colcount==0) AND ($rowcounter<>0)) echo "</tr><tr>";


if ($slimbox4 == 1) { ?>

<td valign="top" width="<?php echo $colwidth;?>"><div align="left"><br />
<a href="<?php echo sefRelToAbs("index.php?option=com_ezrealty&amp;task=detail&amp;id=$row->id&amp;Itemid=$Itemid");?>"><strong><?php echo $row->adline;?></strong></a><br />
<?php if ($row->image1) { ?><a href="components/com_ezrealty/<?php echo $er_imagedirectory;?>/<?php echo $row->image1;?>" rel="lightbox" title="<?php echo $row->adline;?>"><?php } ?><?php if ($row->image1) { ?>
<img src="components/com_ezrealty/<?php echo $er_imagedirectory;?><?php if ( $er_thumbcreation !== 'none' ) { ?>/th<?php } ?>/<?php echo $row->image1;?>" border="0" align="<?php echo $align;?>" style="margin-top: <?php echo $vertspace;?>px; margin-bottom: <?php echo $vertspace;?>px; padding-left: <?php echo $horizspace;?>px; margin-right: <?php echo $horizspace;?>px" width="<?php echo $er_thumbwidth;?>" title="<?php echo $row->adline;?>" alt="<?php echo $row->adline;?>" />
<?php }else{ ?>
<img src="components/com_ezrealty/<?php echo $er_imagedirectory;?>/th/nothumb.gif" align="<?php echo $align;?>" border="0" style="margin-top: <?php echo $vertspace;?>px; margin-bottom: <?php echo $vertspace;?>px; padding-left: <?php echo $horizspace;?>px; margin-right: <?php echo $horizspace;?>px" width="<?php echo $er_thumbwidth;?>" title="<?php echo $row->adline;?>" alt="<?php echo $row->adline;?>" /><?php } ?><?php if ($row->image1) { ?></a><?php } ?>
<?php echo $row->smalldesc;?> <a href='<?php echo sefRelToAbs("index.php?option=com_ezrealty&amp;task=detail&amp;id=$row->id&amp;Itemid=$Itemid");?>'><strong><?php echo _MOD_EZREALTY_MFREADMORE;?></strong></a><br />
<br /></div></td>
<td width="10"><img src="components/com_ezrealty/images/pixel.gif" width="10" alt="" /></td>

<?php } elseif ($slimbox4 == 2) { ?>

<td valign="top" width="<?php echo $colwidth;?>"><div align="left"><br />
<a href="<?php echo sefRelToAbs("index.php?option=com_ezrealty&amp;task=detail&amp;id=$row->id&amp;Itemid=$Itemid");?>"><strong><?php echo $row->adline;?></strong></a><br />
<a href="<?php echo sefRelToAbs("index.php?option=com_ezrealty&amp;task=detail&amp;id=$row->id&amp;Itemid=$Itemid");?>" onmouseover="return overlib('<img src=components/com_ezrealty/<?php if ($row->image1) { ?><?php echo $er_imagedirectory.'/'.$row->image1;?><?php }else{ ?><?php echo $er_imagedirectory;?>/nothumb.gif<?php } ?> width=<?php echo $popwidth4;?> />', VAUTO, HAUTO, '<?php echo $row->adline;?>');" onmouseout="return nd();"><?php if ($row->image1) { ?>
<img src="components/com_ezrealty/<?php echo $er_imagedirectory;?>/th/<?php echo $row->image1;?>" border="0" width="<?php echo $er_thumbwidth;?>" align="<?php echo $align;?>" style="margin-top: <?php echo $vertspace;?>px; margin-bottom: <?php echo $vertspace;?>px; padding-left: <?php echo $horizspace;?>px; margin-right: <?php echo $horizspace;?>px" alt="<?php echo $row->adline;?>" /><?php }else{ ?>
<img src="components/com_ezrealty/<?php echo $er_imagedirectory;?>/th/nothumb.gif" border="0" width="<?php echo $er_thumbwidth;?>" align="<?php echo $align;?>" style="margin-top: <?php echo $vertspace;?>px; margin-bottom: <?php echo $vertspace;?>px; padding-left: <?php echo $horizspace;?>px; margin-right: <?php echo $horizspace;?>px" alt="<?php echo $row->adline;?>" /><?php } ?></a>
<?php echo $row->smalldesc;?> <a href='<?php echo sefRelToAbs("index.php?option=com_ezrealty&amp;task=detail&amp;id=$row->id&amp;Itemid=$Itemid");?>'><strong><?php echo _MOD_EZREALTY_MFREADMORE;?></strong></a><br />
<br /></div></td>
<td width="10"><img src="components/com_ezrealty/images/pixel.gif" width="10" alt="" /></td>

<?php } else { ?>

<td valign="top" width="<?php echo $colwidth;?>"><div align="left"><br />
<a href="<?php echo sefRelToAbs("index.php?option=com_ezrealty&amp;task=detail&amp;id=$row->id&amp;Itemid=$Itemid");?>"><strong><?php echo $row->adline;?></strong></a><br />
<?php if ($row->image1) { ?>
<a href="<?php echo sefRelToAbs("index.php?option=com_ezrealty&amp;task=detail&amp;id=$row->id&amp;Itemid=$Itemid");?>"><img src="components/com_ezrealty/<?php echo $er_imagedirectory;?><?php if ( $er_thumbcreation !== 'none' ) { ?>/th<?php } ?>/<?php echo $row->image1;?>" border="0" align="<?php echo $align;?>" style="margin-top: <?php echo $vertspace;?>px; margin-bottom: <?php echo $vertspace;?>px; padding-left: <?php echo $horizspace;?>px; margin-right: <?php echo $horizspace;?>px" width="<?php echo $er_thumbwidth;?>" title="<?php echo $row->adline;?>" alt="<?php echo $row->adline;?>" />
<?php }else{ ?>
<img src="components/com_ezrealty/<?php echo $er_imagedirectory;?>/th/nothumb.gif" align="<?php echo $align;?>" border="0" style="margin-top: <?php echo $vertspace;?>px; margin-bottom: <?php echo $vertspace;?>px; padding-left: <?php echo $horizspace;?>px; margin-right: <?php echo $horizspace;?>px" width="<?php echo $er_thumbwidth;?>" title="<?php echo $row->adline;?>" alt="<?php echo $row->adline;?>" /><?php } ?><?php if ($row->image1) { ?></a><?php } ?>
<?php echo $row->smalldesc;?> <a href='<?php echo sefRelToAbs("index.php?option=com_ezrealty&amp;task=detail&amp;id=$row->id&amp;Itemid=$Itemid");?>'><strong><?php echo _MOD_EZREALTY_MFREADMORE;?></strong></a><br />
<br /></div></td>
<td width="10"><img src="components/com_ezrealty/images/pixel.gif" width="10" alt="" /></td>

<?php

}


	$rowcounter++;
	}
    if ($rowcounter%$colcount<>0) {
      for ($i = 1; $i <= ($colcount-($rowcounter%$colcount)); $i++) {
        echo "<td width='$colwidth' valign='top'> </td>";
      }
    }

}else{


}

    echo "</tr></table>";

?>

