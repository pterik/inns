<?php

/**
* FileName: mod_ezrealty_search.php
* Date: 16-02-2008
* License: Commercial copyright
* Script Version #: 3.12
* EZ Realty Version #: 5.1.0 stable
* Author: K.J. Strickland - http://www.raptorservices.com.au
**/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

# call some core configuration variables:
global $mainframe, $mosConfig_lang;

# Get the right language file

DEFINE("LANGUAGE_PATH9","modules/mod_ezrealty_search/mod_ezrealty_search");

if (file_exists(LANGUAGE_PATH9."/".$mosConfig_lang.".php")) {
  include(LANGUAGE_PATH9."/".$mosConfig_lang.".php");
} elseif (file_exists(LANGUAGE_PATH9."/english.php"))  {
  include(LANGUAGE_PATH9."/english.php");
} else {
echo "Language file is not available";
}

DEFINE("EZADMIN_PATH9","administrator/components/com_ezrealty");

if (file_exists(EZADMIN_PATH9."/config.ezrealty.php")) {
  include(EZADMIN_PATH9."/config.ezrealty.php");
} else {
echo 'Configuration file not available';
}


$moduleclass_sfx    = $params->get( 'moduleclass_sfx' );


  # Build property type select list

  	$typeit[] = mosHTML::makeOption( 0, _EZREALTY_LISTING_ANYTYPE2 );
if ( $er_usetype1 ) {
  	$typeit[] = mosHTML::makeOption( 1, _EZREALTY_TYPE_SALE2 );
  }
if ( $er_usetype2 ) {
  	$typeit[] = mosHTML::makeOption( 2, _EZREALTY_TYPE_RENTAL2 );
  }
if ( $er_usetype3 ) {
  	$typeit[] = mosHTML::makeOption( 3, _EZREALTY_TYPE_LEASE2 );
  }
if ( $er_usetype4 ) {
  	$typeit[] = mosHTML::makeOption( 4, _EZREALTY_TYPE_AUCTION2 );
  }
if ( $er_usetype5 ) {
  	$typeit[] = mosHTML::makeOption( 5, _EZREALTY_TYPE_SWAP2 );
  }
if ( $er_usetype6 ) {
  	$typeit[] = mosHTML::makeOption( 6, _EZREALTY_TYPE_TENDER2 );
  }
  
  	$lists['type'] = mosHTML::selectList( $typeit, 'type', 'class="searchbox2" size="1"' , 'value', 'text', '' );

 # Build Property Category select list

	$sql	= "SELECT cid as value, name as text FROM #__ezrealty_catg ORDER by ordering";
	$database->setQuery($sql);
	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$ptypelist[] = mosHTML::makeOption( '0', _EZREALTY_SEARCH_ALCAT2 );
	$ptypelist = array_merge( $ptypelist, $database->loadObjectList() );
	$lists['cid'] = mosHTML::selectList( $ptypelist, 'cid', 'class="searchbox2" size="1"','value', 'text', '');

  # Build Min Price select list

	$sql	= "SELECT a.range as value, a.display as text FROM #__ezrealty_price AS a WHERE a.published=1 ORDER by ordering";
	$database->setQuery($sql);
	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$minpriceit[] = mosHTML::makeOption( '', _EZREALTY_MINPRICE2 );
	$minpriceit = array_merge( $minpriceit, $database->loadObjectList() );
	$lists['minprice'] = mosHTML::selectList( $minpriceit, 'minprice', 'class="searchbox2" size="1"','value', 'text', '');


  # Build Max Price select list

	$sql	= "SELECT b.range as value, b.display as text FROM #__ezrealty_price AS b WHERE b.published=1 ORDER by b.ordering";
	$database->setQuery($sql);
	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$maxpriceit[] = mosHTML::makeOption( '', _EZREALTY_MAXPRICE2 );
	$maxpriceit = array_merge( $maxpriceit, $database->loadObjectList() );
	$lists['maxprice'] = mosHTML::selectList( $maxpriceit, 'maxprice', 'class="searchbox2" size="1"','value', 'text', '');


if ( $er_uselocid == 1 ) {

 # Build State select list - Locality select will be built by ajax


    $sql = "SELECT stid as value, name as text FROM #__ezrealty_state ORDER by name";
    $database->setQuery($sql);
    if (!$database->query()) {
    echo $database->stderr();
    return;
    }

    $mtypelist2[] = mosHTML::makeOption( '0', _EZREALTY_SEARCH_ALSTA2 );
    $mtypelist2 = array_merge( $mtypelist2, $database->loadObjectList() );
    $lists['stid'] = mosHTML::selectList( $mtypelist2, 'stid', 'class="searchbox2" id="stid2" size="1" onchange="getDropLocList2(this,0)" ','value', 'text', '');


   $sql = "SELECT locid as value, ezcity as text FROM #__ezrealty_locality ORDER by ezcity";
    $database->setQuery($sql);
    if (!$database->query()) {
    echo $database->stderr();
    return;
    }

    $mltypelist2[] = mosHTML::makeOption( '0', _EZREALTY_SEARCH_ALLOC2 );
    $lists['locid'] = mosHTML::selectList( $mltypelist2, 'locid', 'class="searchbox2" id="locid2" size="1" ','value', 'text', '');

}

if ( $er_uselocid == 2 ) { 


  # Build secondary Locality select list

	$sql	= "SELECT locid as value, ezcity as text FROM #__ezrealty_locality WHERE published=1 ORDER by ezcity";
	$database->setQuery($sql);
	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$localitylist2[] = mosHTML::makeOption( '0', _EZREALTY_SEARCH_ALLOC2 );
	$localitylist2 = array_merge( $localitylist2, $database->loadObjectList() );
	$lists['locid'] = mosHTML::selectList( $localitylist2, 'locid', 'class="searchbox2" size="1"','value', 'text', '');

}

  # Build Country select list

	$sql	= "SELECT cnid as value, name as text FROM #__ezrealty_country ORDER by name";
	$database->setQuery($sql);
	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$countrylist[] = mosHTML::makeOption( '0', _EZREALTY_SEARCH_ALCOU2 );
	$countrylist = array_merge( $countrylist, $database->loadObjectList() );
	$lists['cnid'] = mosHTML::selectList( $countrylist, 'cnid', 'class="searchbox2" size="1"','value', 'text', '');

  # Build PostCode select list

	$sql	= "SELECT DISTINCT postcode as value, postcode as text FROM #__ezrealty WHERE published = 1 ORDER by postcode";
	$database->setQuery($sql);
	$rpc = $database->loadObjectList();

	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$postcodelist[] = mosHTML::makeOption( '', _EZREALTY_SEARCH_ALLPOSTCODES2 );
if ($rpc){
	$postcodelist = array_merge( $postcodelist, $database->loadObjectList() );
}
	$lists['postcode'] = mosHTML::selectList( $postcodelist, 'postcode', 'class="searchbox2" size="1"','value', 'text', '');

  # Build Min Bedroom select list

	$sql	= "SELECT number as value, number as text FROM #__ezrealty_room ORDER by ordering";
	$database->setQuery($sql);
	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$minbedit[] = mosHTML::makeOption( '', _EZREALTY_MINBED2 );
	$minbedit[] = mosHTML::makeOption( '0.5', _EZREALTY_STUDIO2 );
	$minbedit = array_merge( $minbedit, $database->loadObjectList() );
	$lists['minbed'] = mosHTML::selectList( $minbedit, 'minbed', 'class="searchbox2" size="1"','value', 'text', '');


  # Build Max Bedroom select list

	$sql	= "SELECT number as value, number as text FROM #__ezrealty_room ORDER by ordering";
	$database->setQuery($sql);
	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$maxbedit[] = mosHTML::makeOption( '', _EZREALTY_MAXBED2 );
	$maxbedit[] = mosHTML::makeOption( '0.5', _EZREALTY_STUDIO2 );
	$maxbedit = array_merge( $maxbedit, $database->loadObjectList() );
	$lists['maxbed'] = mosHTML::selectList( $maxbedit, 'maxbed', 'class="searchbox2" size="1"','value', 'text', '');


  # Build Market Status select list

	$soldit[] = mosHTML::makeOption( 0, _EZREALTY_SEARCH_ANYMARKET2 );
if ( $er_usemarket1 ) {
	$soldit[] = mosHTML::makeOption( 1, _EZREALTY_DETAILS_MARKET1A );
  }
if ( $er_usemarket2 ) {
  	$soldit[] = mosHTML::makeOption( 2, _EZREALTY_DETAILS_MARKET2A );
  }
if ( $er_usemarket3 ) {
  	$soldit[] = mosHTML::makeOption( 3, _EZREALTY_DETAILS_MARKET3A );
  }
if ( $er_usemarket4 ) {
  	$soldit[] = mosHTML::makeOption( 4, _EZREALTY_DETAILS_MARKET4A );
  }
if ( $er_usemarket5 ) {
  	$soldit[] = mosHTML::makeOption( 5, _EZREALTY_DETAILS_MARKET5A );
  }
if ( $er_usemarket6 ) {
  	$soldit[] = mosHTML::makeOption( 6, _EZREALTY_DETAILS_MARKET6A );
  }
  
  	$lists['sold'] = mosHTML::selectList( $soldit, 'sold', 'class="searchbox2" size="1"' , 'value', 'text', '' );


  # Build MLS # select list

	$sql	= "SELECT DISTINCT mls_id as value, mls_id as text FROM #__ezrealty WHERE published = 1 AND mls_id != '' ORDER by mls_id";
	$database->setQuery($sql);
	$rmlss = $database->loadObjectList();

	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$mlslist[] = mosHTML::makeOption( '', _EZREALTY_SEARCH_ANYMLS2 );
if ($rmlss){
	$mlslist = array_merge( $mlslist, $database->loadObjectList() );
}
	$lists['mls_id'] = mosHTML::selectList( $mlslist, 'mls_id', 'class="searchbox2" size="1"','value', 'text', '');


  # Build Bathroom select list

	$sql	= "SELECT DISTINCT ba.bathrooms as value, ba.bathrooms as text FROM #__ezrealty AS ba WHERE ba.published=1 AND ba.bathrooms !='' ORDER by ba.bathrooms";
	$database->setQuery($sql);
	$rbathrooms = $database->loadObjectList();

	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$bathit[] = mosHTML::makeOption( '', _EZREALTY_SELECT_BATHROOMS_2 );
if ($rbathrooms){
	$bathit = array_merge( $bathit, $database->loadObjectList() );
}
	$lists['bath'] = mosHTML::selectList( $bathit, 'bathrooms', 'class="searchbox2" size="1"','value', 'text', '');


  # Build custom 4 select list

	$sql	= "SELECT DISTINCT t.custom4 as value, t.custom4 as text FROM #__ezrealty AS t WHERE t.published=1 AND t.custom4 !='' ORDER by t.custom4";
	$database->setQuery($sql);
	$rcustom4 = $database->loadObjectList();

	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$custom4it[] = mosHTML::makeOption( '', _EZREALTY_ANYCUSTOM4_2 );
if ($rcustom4){
	$custom4it = array_merge( $custom4it, $database->loadObjectList() );
}
	$lists['custom4'] = mosHTML::selectList( $custom4it, 'custom4', 'class="searchbox2" size="1"','value', 'text', '');


  # Build custom 5 select list

	$sql	= "SELECT DISTINCT custom5 as value, custom5 as text FROM #__ezrealty WHERE published=1 AND custom5 !='' ORDER by custom5";
	$database->setQuery($sql);
	$rcustom5 = $database->loadObjectList();

	if (!$database->query()) {
		echo $database->stderr();
		return;
	}

	$custom5it[] = mosHTML::makeOption( '', _EZREALTY_ANYCUSTOM5_2 );
if ($rcustom5){
	$custom5it = array_merge( $custom5it, $database->loadObjectList() );
}
	$lists['custom5'] = mosHTML::selectList( $custom5it, 'custom5', 'class="searchbox2" size="1"','value', 'text', '');


  # Build Pets allowed select list

	$petit[] = mosHTML::makeOption( 0, _EZREALTY_NA2 );
	$petit[] = mosHTML::makeOption( 1, _EZREALTY_CONFIG_NO2 );
  	$petit[] = mosHTML::makeOption( 2, _EZREALTY_CONFIG_YES2 );
  	$petit[] = mosHTML::makeOption( 3, _EZREALTY_HELPER_PETS2 );
  
  	$lists['pets'] = mosHTML::selectList( $petit, 'pets', 'class="searchbox2" size="1"' , 'value', 'text', '' );


  # Build garage select list

  	$lugit[] = mosHTML::makeOption( 0, _EZREALTY_LUG_NO2 );
  	$lugit[] = mosHTML::makeOption( 1, _EZREALTY_LUG_YES2 );
  
  	$lists['lug'] = mosHTML::selectList( $lugit, 'lug', 'class="searchbox2" size="1"' , 'value', 'text', '' );


// Find EZ Realty Itemid from the menu table

	$query = "SELECT * from #__menu"
	. "\n WHERE link = 'index.php?option=com_ezrealty'"
	;
	$database->setQuery( $query );
	$id = $database->loadResult();
	$Itemid = $id;

?>

<script type="text/javascript" src="<?php echo $mosConfig_live_site;?>/components/com_ezrealty/library/ajax/ajax.js"></script>

<table class="moduletable<?php echo $moduleclass_sfx;?>">

<tr><td>

	<form name="searchfilter" action="<?php echo sefRelToAbs("index.php?option=com_ezrealty&amp;Itemid=$Itemid&amp;task=results");?>" method="post">
	<input type="hidden" name="option" value="com_ezrealty" />
	<input type="hidden" name="Itemid" value="<?php echo $Itemid;?>" />
	<input type="hidden" name="task" value="results" />
<?php if (!$er_usetype) { ?>
	<input type="hidden" name="type" value="0" />
<?php } ?>
<?php if (!$er_usecid) { ?>
	<input type="hidden" name="cid" value="0" />
<?php } ?>
<?php if ($er_uselocid == 0) { ?>
	<input type="hidden" name="stid" value="0" />
	<input type="hidden" name="locid" value="0" />
<?php } ?>
<?php if ($er_uselocid == 2) { ?>
	<input type="hidden" name="stid" value="0" />
<?php } ?>
<?php if (!$er_usecnid) { ?>
	<input type="hidden" name="cnid" value="0" />
<?php } ?>
<?php if (!$er_usepostcode) { ?>
	<input type="hidden" name="postcode" value="" />
<?php } ?>
<?php if (!$er_useprice) { ?>
	<input type="hidden" name="minprice" value="" />
	<input type="hidden" name="maxprice" value="" />
<?php } ?>
<?php if (!$er_usebed) { ?>
	<input type="hidden" name="minbed" value="" />
	<input type="hidden" name="maxbed" value="" />
<?php } ?>
<?php if (!$er_usesold) { ?>
	<input type="hidden" name="sold" value="0" />
<?php } ?>
<?php if (!$er_usemls) { ?>
	<input type="hidden" name="mls_id" value="" />
<?php } ?>
<?php if (!$er_usebath) { ?>
	<input type="hidden" name="bathrooms" value="" />
<?php } ?>
<?php if (!$er_usecust4) { ?>
	<input type="hidden" name="custom4" value="" />
<?php } ?>
<?php if (!$er_usecust5) { ?>
	<input type="hidden" name="custom5" value="" />
<?php } ?>
<table border="0" cellspacing="2" width="100%">

<?php if ($er_usetype) { ?>
	<tr>
		<td width="100"><?php echo $lists['type'];?></td>
	</tr>
<?php } ?>
<?php if ($er_usecid) { ?>
	<tr>
		<td width="100"><?php echo $lists['cid'];?></td>
	</tr>
<?php } ?>
<?php if ( $er_uselocid == 1 ) { ?>
	<tr>
		<td><?php echo $lists['stid'];?></td>
	</tr>
	<tr>
		<td><?php echo $lists['locid'];?></td>
	</tr>
<?php } ?>
<?php if ( $er_uselocid == 2 ) { ?>
	<tr>
		<td><?php echo $lists['locid'];?></td>
	</tr>
<?php } ?>



<?php if ( $er_usecnid ) { ?>
	<tr>
		<td><?php echo $lists['cnid'];?></td>
	</tr>
<?php } ?>
<?php if ($er_usepostcode) { ?>
	<tr>
		<td><?php echo $lists['postcode'];?></td>
	</tr>
<?php } ?>
<?php if ($er_useprice) { ?>
	<tr>
		<td><?php echo $lists['minprice'];?></td>
	</tr>
	<tr>
		<td><?php echo $lists['maxprice'];?></td>
	</tr>
<?php } ?>
<?php if ($er_usebed) { ?>
	<tr>
		<td><?php echo $lists['minbed'];?></td>
	</tr>
	<tr>
		<td><?php echo $lists['maxbed'];?></td>
	</tr>
<?php } ?>
<?php if ($er_usebath) { ?>
	<tr>
		<td><?php echo $lists['bath'];?></td>
	</tr>
<?php } ?>
<?php if ($er_usesold) { ?>
	<tr>
		<td><?php echo $lists['sold'];?></td>
	</tr>
<?php } ?>
<?php if ($er_usemls) { ?>
	<tr>
		<td><?php echo $lists['mls_id'];?></td>
	</tr>
<?php } ?>
<?php if ($er_usepets) { ?>
	<tr>
		<td><?php echo $lists['pets'];?></td>
	</tr>
<?php } ?>
<?php if ($er_uselug) { ?>
	<tr>
		<td><?php echo $lists['lug'];?></td>
	</tr>
<?php } ?>
<?php if ($er_usecust4) { ?>
	<tr>
		<td><?php echo $lists['custom4'];?></td>
	</tr>
<?php } ?>
<?php if ($er_usecust5) { ?>
	<tr>
		<td><?php echo $lists['custom5'];?></td>
	</tr>
<?php } ?>


	<tr>
		<td><strong><?php echo _EZREALTY_SEARCHORD2;?>:-</strong><br />
		<select name="direction" class="searchbox2"> 
		<option value="ASCPRICE"><?php echo _EZREALTY_SEARCH_PRIASC2;?></option>
		<option value="DESCPRICE"><?php echo _EZREALTY_SEARCH_PRIDESC2;?></option>
		<option value="ASCID"><?php echo _EZREALTY_SEARCH_ASC2;?></option>
		<option value="DESCID"><?php echo _EZREALTY_SEARCH_DESC2;?></option>
		</select>
		</td>
	</tr>
	<tr>
		<td><input class="button" type="submit" name="<?php echo _EZREALTY_SEARCH_SEARCH2;?>" value="<?php echo _EZREALTY_SEARCH_SEARCH2;?>" /></td>
	</tr>
</table>

	</form>
</td></tr></table>
