<?php

#############################################################################
#                                                                           #
#  EZ Realty 4.0.0 - A Joomla/Mambo Real Estate component                   #
#  EZ Realty Search Module Language File version 3.4                        #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
#  http://www.raptorservices.com.au                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################

    /**** LANGUAGE FILE INFO *****************\
    **
    **   English language
    **   By: K.J. Strickland (aka PixelBunyiP)
    **   http://www.raptorservices.com.au
    **
    \*****************************************/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


DEFINE("_EZREALTY_LISTING_ANYTYPE2","Angebotsart");
DEFINE("_EZREALTY_TYPE_SALE2","Verkauf");
DEFINE("_EZREALTY_TYPE_RENTAL2","Vermietung");
DEFINE("_EZREALTY_LISTING_TYPE2","Angebotsart");
DEFINE("_EZREALTY_CATEGORY_CATNAME2","Kategorie");
DEFINE("_EZREALTY_SEARCHLOC2","Ort");
DEFINE("_EZREALTY_SEARCHREG2","Bundesland");
DEFINE("_EZREALTY_SEARCHCON2","Land");
DEFINE("_EZREALTY_MINBED2","Min. Schlafzimmer");
DEFINE("_EZREALTY_MAXBED2","Max. Schlafzimmer");
DEFINE("_EZREALTY_MINPRICE2","Min. Preis");
DEFINE("_EZREALTY_MAXPRICE2","Max. Preis");
DEFINE("_EZREALTY_SEARCH_PRIASC2","Preis aufsteigend");
DEFINE("_EZREALTY_SEARCH_PRIDESC2","Preis absteigend");
DEFINE("_EZREALTY_SEARCH_ASC2","Datum aufsteigend");
DEFINE("_EZREALTY_SEARCH_DESC2","Datum absteigend");
DEFINE("_EZREALTY_SEARCH_SEARCH2","Suche");
DEFINE("_EZREALTY_SEARCH_ALCAT2","W�hle alle Kategorien");
DEFINE("_EZREALTY_SEARCH_ALLOC2","W�hle alle Orte");
DEFINE("_EZREALTY_SEARCH_ALSTA2","W�hle alle Bundesl�nder");
DEFINE("_EZREALTY_SEARCH_ALCOU2","W�hle alle L�nder");
DEFINE("_EZREALTY_SEARCHORD2","Ordnen");
DEFINE("_EZREALTY_SEARCH_ALLPOSTCODES2","W�hlen Sie alle PostCodes vor");
DEFINE("_EZREALTY_DETAILS_PROPPOSTCODE2","Zip/Pfosten-Code");

DEFINE("_EZREALTY_DETAILS_MARKETA","Markt-Status");
DEFINE("_EZREALTY_DETAILS_MARKET1A","Nicht verkauft/Vorhanden");
DEFINE("_EZREALTY_DETAILS_MARKET2A","Unter Angebot");
DEFINE("_EZREALTY_DETAILS_MARKET3A","Abh�ngig von Vertrag");
DEFINE("_EZREALTY_DETAILS_MARKET4A","Unter Vertrag");
DEFINE("_EZREALTY_DETAILS_MARKET5A","Verkauft");
DEFINE("_EZREALTY_STUDIO2","Studio");

DEFINE("_EZREALTY_ANYCUSTOM4_2","Any custom 4");
DEFINE("_EZREALTY_ANYCUSTOM5_2","Any custom 5");
DEFINE("_EZREALTY_SELECT_BATHROOMS_2","Any bathroom number");



?>