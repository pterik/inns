<?php

#############################################################################
#                                                                           #
#  EZ Realty Search Module Language File version 3.10                       #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
#  http://www.raptorservices.com.au                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################

    /**** LANGUAGE FILE INFO *****************\
    **   
    **   English language
    **   By: K.J. Strickland (aka PixelBunyiP)
    **   http://www.raptorservices.com.au
    **  
    \*****************************************/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


DEFINE("_EZREALTY_LISTING_ANYTYPE2","Any Listing Type");
DEFINE("_EZREALTY_TYPE_SALE2","For Sale");
DEFINE("_EZREALTY_TYPE_RENTAL2","For Rent");
DEFINE("_EZREALTY_LISTING_TYPE2","Listing Type");
DEFINE("_EZREALTY_CATEGORY_CATNAME2","Category");
DEFINE("_EZREALTY_SEARCHLOC2","Locality");
DEFINE("_EZREALTY_SEARCHREG2","State");
DEFINE("_EZREALTY_SEARCHCON2","Country");
DEFINE("_EZREALTY_MINBED2","Min Bedrooms");
DEFINE("_EZREALTY_MAXBED2","Max Bedrooms");
DEFINE("_EZREALTY_MINPRICE2","Min Price");
DEFINE("_EZREALTY_MAXPRICE2","Max Price");
DEFINE("_EZREALTY_SEARCH_PRIASC2","Price Ascending");
DEFINE("_EZREALTY_SEARCH_PRIDESC2","Price Descending");
DEFINE("_EZREALTY_SEARCH_ASC2","Date Ascending");
DEFINE("_EZREALTY_SEARCH_DESC2","Date Descending");
DEFINE("_EZREALTY_SEARCH_SEARCH2","Search");
DEFINE("_EZREALTY_SEARCH_ALCAT2","Select all Categories");
DEFINE("_EZREALTY_SEARCH_ALLOC2","Select all Localities");
DEFINE("_EZREALTY_SEARCH_ALSTA2","Select all States");
DEFINE("_EZREALTY_SEARCH_ALCOU2","Select all Countries");
DEFINE("_EZREALTY_SEARCHORD2","Order");
DEFINE("_EZREALTY_SEARCH_ALLPOSTCODES2","Select all PostCodes");
DEFINE("_EZREALTY_DETAILS_PROPPOSTCODE2","Zip/Post Code");

DEFINE("_EZREALTY_DETAILS_MARKETA","Market Status");
DEFINE("_EZREALTY_DETAILS_MARKET1A","Unsold/Available");
DEFINE("_EZREALTY_DETAILS_MARKET2A","Under Offer");
DEFINE("_EZREALTY_DETAILS_MARKET3A","Subject to Contract");
DEFINE("_EZREALTY_DETAILS_MARKET4A","Under Contract");
DEFINE("_EZREALTY_DETAILS_MARKET5A","Sold");
DEFINE("_EZREALTY_DETAILS_MARKET6A","Unavailable");
DEFINE("_EZREALTY_STUDIO2","Studio");

DEFINE("_EZREALTY_TYPE_LEASE2","For Lease");
DEFINE("_EZREALTY_TYPE_AUCTION2","For Auction");
DEFINE("_EZREALTY_CONFIG_NO2","No");
DEFINE("_EZREALTY_CONFIG_YES2","Yes");
DEFINE("_EZREALTY_LUG_NO2","No Garage");
DEFINE("_EZREALTY_LUG_YES2","Garage");
DEFINE("_EZREALTY_SEARCH_ANYMLS2","Any MLS");
DEFINE("_EZREALTY_SEARCH_ANYMARKET2","Any Market Status");
DEFINE("_EZREALTY_SEARCH_ANY2","Any");
DEFINE("_EZREALTY_HELPER_PETS2","Helper Animals");
DEFINE("_EZREALTY_NA2","Any Pets Status");

DEFINE("_EZREALTY_TYPE_TENDER2","Sale by Tender");
DEFINE("_EZREALTY_TYPE_SWAP2","Property Exchange");

DEFINE("_EZREALTY_ANYCUSTOM4_2","Any custom 4");
DEFINE("_EZREALTY_ANYCUSTOM5_2","Any custom 5");

DEFINE("_EZREALTY_SELECT_BATHROOMS_2","Any bathroom number");

?>