<?php

#############################################################################
#                                                                           #
#  EZ Realty 4.0.0 - A Joomla/Mambo Real Estate component                   #
#  EZ Realty Search Module Language File version 3.5                        #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
#  http://www.raptorservices.com.au                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################

    /**** LANGUAGE FILE INFO *****************\
    **   
    **   Polish language
	**	 Encoding: ISO-8859-2
    **   By: Grzegorz Grajewski (aka el Donut)
    **   http://www.webarcane.com
    **  
    \*****************************************/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


DEFINE("_EZREALTY_LISTING_ANYTYPE2","Dowolny typ oferty");
DEFINE("_EZREALTY_TYPE_SALE2","Na sprzeda�");
DEFINE("_EZREALTY_TYPE_RENTAL2","Do wynaj�cia");
DEFINE("_EZREALTY_LISTING_TYPE2","Typ wy�wietlania");
DEFINE("_EZREALTY_CATEGORY_CATNAME2","Kategoria");
DEFINE("_EZREALTY_SEARCHLOC2","Okolica");
DEFINE("_EZREALTY_SEARCHREG2","Stan");
DEFINE("_EZREALTY_SEARCHCON2","Polska");
DEFINE("_EZREALTY_MINBED2","Wybierz minimaln� liczb� sypialni");
DEFINE("_EZREALTY_MAXBED2","Wybierz maksymaln� liczb� sypialni");
DEFINE("_EZREALTY_MINPRICE2","Wybierz minimalna cene");
DEFINE("_EZREALTY_MAXPRICE2","Wybierz maksymaln� cen�");
DEFINE("_EZREALTY_SEARCH_PRIASC2","Cena rosn�co");
DEFINE("_EZREALTY_SEARCH_PRIDESC2","Cena malej�co");
DEFINE("_EZREALTY_SEARCH_ASC2","Data rosn�co");
DEFINE("_EZREALTY_SEARCH_DESC2","Data malej�co");
DEFINE("_EZREALTY_SEARCH_SEARCH2","Szukaj");
DEFINE("_EZREALTY_SEARCH_ALCAT2","Wybierz wszystkie kategorie");
DEFINE("_EZREALTY_SEARCH_ALLOC2","Wybierz wszystkie lokalizacje");
DEFINE("_EZREALTY_SEARCH_ALSTA2","Wybierz wszystkie wojew�dztwa");
DEFINE("_EZREALTY_SEARCH_ALCOU2","Wybierz wszystkie kraje");
DEFINE("_EZREALTY_SEARCHORD2","Kolejno��");
DEFINE("_EZREALTY_SEARCH_ALLPOSTCODES2","Wybierz wszystkie kody pocztowe");
DEFINE("_EZREALTY_DETAILS_PROPPOSTCODE2","Kod pocztowy");

DEFINE("_EZREALTY_DETAILS_MARKETA","Status oferty");
DEFINE("_EZREALTY_DETAILS_MARKET1A","Niesprzedane/Dost�pne");
DEFINE("_EZREALTY_DETAILS_MARKET2A","Zg�oszono ofert�");
DEFINE("_EZREALTY_DETAILS_MARKET3A","Sprzeda� uzale�niona od zawarcia umowy pisemnej ");
DEFINE("_EZREALTY_DETAILS_MARKET4A","W trakcie finalizacji");
DEFINE("_EZREALTY_DETAILS_MARKET5A","Sprzedane");
DEFINE("_EZREALTY_STUDIO2","Studio");

DEFINE("_EZREALTY_ANYCUSTOM4_2","Any custom 4");
DEFINE("_EZREALTY_ANYCUSTOM5_2","Any custom 5");
DEFINE("_EZREALTY_SELECT_BATHROOMS_2","Any bathroom number");

?>