<?php

#############################################################################
#                                                                           #
#  EZ Realty Search Module Language File version 3.10                       #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
#  http://www.raptorservices.com.au                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################

    /**** LANGUAGE FILE INFO *****************\
    **   
    **   greek language
    **   By: kostoulidis panagiotis
    **   http://www.vitualaggelies.com
    **  
    \*****************************************/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


DEFINE("_EZREALTY_LISTING_ANYTYPE2","Ακίνητα προς");
DEFINE("_EZREALTY_TYPE_SALE2","Πώληση");
DEFINE("_EZREALTY_TYPE_RENTAL2","Εκμίσθωση");
DEFINE("_EZREALTY_LISTING_TYPE2","Τύπος Ακινήτου");
DEFINE("_EZREALTY_CATEGORY_CATNAME2","Κατηγορία Ακινήτου");
DEFINE("_EZREALTY_SEARCHLOC2","Περιοχή");
DEFINE("_EZREALTY_SEARCHREG2","Νομός");
DEFINE("_EZREALTY_SEARCHCON2","Χώρα");
DEFINE("_EZREALTY_MINBED2","Υπνοδωμάτια ελάχιστο");
DEFINE("_EZREALTY_MAXBED2","Υπνοδωμάτια μέγιστο");
DEFINE("_EZREALTY_MINPRICE2","Τιμή μικρότερη");
DEFINE("_EZREALTY_MAXPRICE2","Τιμή μεγαλύτερη");
DEFINE("_EZREALTY_SEARCH_PRIASC2","Αύξουσα Τιμή");
DEFINE("_EZREALTY_SEARCH_PRIDESC2","Φθίνουσα Τιμή");
DEFINE("_EZREALTY_SEARCH_ASC2","Αύξουσα Ημερομηνία");
DEFINE("_EZREALTY_SEARCH_DESC2","Φθίνουσα Ημερομηνία");
DEFINE("_EZREALTY_SEARCH_SEARCH2","ΑΝΑΖΗΤΗΣΗ");
DEFINE("_EZREALTY_SEARCH_ALCAT2","Όλες οι Κατηγορίες");
DEFINE("_EZREALTY_SEARCH_ALLOC2","Όλες οι Περιοχές");
DEFINE("_EZREALTY_SEARCH_ALSTA2","Όλοι οι Νομοί");
DEFINE("_EZREALTY_SEARCH_ALCOU2","Όλες οι Χώρες");
DEFINE("_EZREALTY_SEARCHORD2","Επιλογή");
DEFINE("_EZREALTY_SEARCH_ALLPOSTCODES2","Ολοι οι Ταχ.Κώδικες");
DEFINE("_EZREALTY_DETAILS_PROPPOSTCODE2","Ταχ.κώδικας");

DEFINE("_EZREALTY_DETAILS_MARKETA","Κατάσταση Πώλησης");
DEFINE("_EZREALTY_DETAILS_MARKET1A","Διαθέσιμο");
DEFINE("_EZREALTY_DETAILS_MARKET2A","Υπο Προσφορά");
DEFINE("_EZREALTY_DETAILS_MARKET3A","Πριν τα Συμβόλαια");
DEFINE("_EZREALTY_DETAILS_MARKET4A","Στα Συμβόλαια");
DEFINE("_EZREALTY_DETAILS_MARKET5A","Πουλήθηκε");
DEFINE("_EZREALTY_DETAILS_MARKET6A","Σε Παύση");
DEFINE("_EZREALTY_STUDIO2","Studio");

DEFINE("_EZREALTY_TYPE_LEASE2","Για Leasing");
DEFINE("_EZREALTY_TYPE_AUCTION2","Για Πλειστηριασμό");
DEFINE("_EZREALTY_CONFIG_NO2","Οχι");
DEFINE("_EZREALTY_CONFIG_YES2","Ναι");
DEFINE("_EZREALTY_LUG_NO2","Χωρίς Γκαράζ");
DEFINE("_EZREALTY_LUG_YES2","Με Γκαράζ");
DEFINE("_EZREALTY_SEARCH_ANYMLS2","Ολα τα Δίκτυα");
DEFINE("_EZREALTY_SEARCH_ANYMARKET2","Οποιαδήποτε Κατάσταση");
DEFINE("_EZREALTY_SEARCH_ANY2","Ολα");
DEFINE("_EZREALTY_HELPER_PETS2","Ζώα Βοηθοί");
DEFINE("_EZREALTY_NA2","Ζώα");

DEFINE("_EZREALTY_TYPE_TENDER2","Πώληση από Αμεση Ανάγκη");
DEFINE("_EZREALTY_TYPE_SWAP2","Ανταλλαγή Ακινήτων");

DEFINE("_EZREALTY_ANYCUSTOM4_2","4");
DEFINE("_EZREALTY_ANYCUSTOM5_2","5");

DEFINE("_EZREALTY_SELECT_BATHROOMS_2","Μπάνια");

?>