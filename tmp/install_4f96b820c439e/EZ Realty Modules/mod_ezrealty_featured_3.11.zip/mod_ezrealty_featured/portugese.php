<?php



#############################################################################

#                                                                           #

#  EZ Autos 5.0.0 - A Mambo Motor Vehicle Sales Listing component           #

#  By: Kathy Strickland (aka PixelBunyiP)                                   #

#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #

#  All rights reserved                                                      #

#  http://www.raptorservices.com.au                                         #

#  Released as a commercial component!                                      #

#                                                                           #

#############################################################################



    /**** LANGUAGE FILE INFO *****************\

    **   

    **   English language

    **   By: K.J. Strickland (aka PixelBunyiP)

    **   http://www.raptorservices.com.au

    **  

    \*****************************************/





defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );





DEFINE("_MOD_EZREALTY_FREADMORE","<br/>Ler Mais...");

DEFINE("_MOD_EZREALTY_RENTAL_NIGHTLY","Per night");

DEFINE("_MOD_EZREALTY_RENTAL_WEEKLY","Per week");

DEFINE("_MOD_EZREALTY_RENTAL_FNIGHT","Per fortnight");

DEFINE("_MOD_EZREALTY_RENTAL_MONTH","Per month");

DEFINE("_MOD_EZREALTY_RENTAL_SQFT","Per square foot");

DEFINE("_MOD_EZREALTY_RENTAL_SQMTR","Per square metre");

DEFINE("_MOD_EZREALTY_RENTAL_SPARE","Spare entry");



?>