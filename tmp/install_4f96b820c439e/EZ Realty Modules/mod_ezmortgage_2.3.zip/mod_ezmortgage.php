<?php

/**
* FileName: mod_ezmortgage.php
* Date: 16-02-2008
* License: Commercial Copyright
* Script Version #: 2.3
* Author: K.J. Strickland - http://www.raptorservices.com.au
**/

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


# call some core configuration variables:
global $mainframe, $mosConfig_lang;

# Get the right language file

DEFINE("LANGUAGE_PATH13","modules/mod_ezmortgage/mod_ezmortgage");

if (file_exists(LANGUAGE_PATH13."/".$mosConfig_lang.".php")) {
  include(LANGUAGE_PATH13."/".$mosConfig_lang.".php");
} elseif (file_exists(LANGUAGE_PATH13."/english.php"))  {
  include(LANGUAGE_PATH13."/english.php");
} else {
echo "Language file is not available";
}

$moduleclass_sfx    = $params->get( 'moduleclass_sfx' );


echo '<table class="moduletable' . $moduleclass_sfx .'">';
echo '<tr>';
echo '<td>';

?>

 <script type="text/javascript">

<!--

function cal()
{
f = document.borrow;
income = Math.floor(f.income.value) *12*4;
yourdebt = income;
f.loan.value = currency(yourdebt);
}


function currency(num)
{
var dollars = Math.floor(num);
for (var i = 0; i < num.length; i++)
{
  if (num.charAt(i) == ".")
break;
}
var cents = "" + Math.round(num * 100);
cents = cents.substring(cents.length-2, cents.length);
return (dollars + "." + cents);
}
//-->

</script>

<?php echo _EZMORTGAGE_INTRO; ?></td>
	</tr>

<tr>
	<td>

<form method="post" name="borrow" action="">

<table>

	<tr> 
		<td><?php echo _EZMORTGAGE_AMOUNT; ?>:<br />
					<?php echo _EZMORTGAGE_CURRENCY; ?> <input class="inputbox" type="text" name="income" size="15" maxlength="15" /></td>
	</tr>
	<tr> 
		<td>  
			<input class="button" type="button" onclick="cal()" name="<?php echo _EZMORTGAGE_CALC; ?>" value="<?php echo _EZMORTGAGE_CALC; ?>" />
			<input class="button" type="reset" name="<?php echo _EZMORTGAGE_CLEAR; ?>" value="<?php echo _EZMORTGAGE_CLEAR; ?>" />
		</td>
	</tr>
	<tr> 
		<td><i><?php echo _EZMORTGAGE_REPAY; ?></i> <br />
		<?php echo _EZMORTGAGE_CURRENCY; ?> <input class="inputbox" type="text" size="15" maxlength="15" name="loan" />
		</td>
	</tr>
</table>

</form>

		</td>
	</tr>

</table>

