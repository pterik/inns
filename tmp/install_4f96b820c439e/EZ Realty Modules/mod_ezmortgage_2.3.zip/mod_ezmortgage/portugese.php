<?php



#############################################################################

#                                                                           #

#  EZ Realty 4.0.0 - A Joomla/Mambo Real Estate component                   #

#  EZ Mortgage Module Language File version 2.1                             #

#  By: Kathy Strickland (aka PixelBunyiP)                                   #

#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #

#  All rights reserved                                                      #

#  http://www.raptorservices.com.au                                         #

#  Released as a commercial component!                                      #

#                                                                           #

#############################################################################



    /**** LANGUAGE FILE INFO *****************\

    **   

    **   English language

    **   By: K.J. Strickland (aka PixelBunyiP)

    **   http://www.raptorservices.com.au

    **  

    \*****************************************/





defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );





DEFINE("_EZMORTGAGE_INTRO","Quanto � que eu posso pedir? Veja R�pido.");

DEFINE("_EZMORTGAGE_AMOUNT","Rendimento Mensal (depois dos descontos)");

DEFINE("_EZMORTGAGE_CURRENCY","�");

DEFINE("_EZMORTGAGE_REPAY","Capacidade m�xima do Empr�stimo");

DEFINE("_EZMORTGAGE_CALC","Calcular");

DEFINE("_EZMORTGAGE_CLEAR","Limpar");





?>