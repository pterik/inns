<?php

#############################################################################
#                                                                           #
#  EZ Realty 4.0.0 - A Joomla/Mambo Real Estate component                   #
#  EZ Mortgage Module Language File version 2.1                             #
#  By: Kathy Strickland (aka PixelBunyiP)                                   #
#  Copyright (C) 2006 K.J. Strickland, Raptor Developments Pty Ltd          #
#  All rights reserved                                                      #
#  http://www.raptorservices.com.au                                         #
#  Released as a commercial component!                                      #
#                                                                           #
#############################################################################

    /**** LANGUAGE FILE INFO *****************\
    **   
    **   English language
    **   By: K.J. Strickland (aka PixelBunyiP)
    **   http://www.raptorservices.com.au
    **  
    \*****************************************/


defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );


DEFINE("_EZMORTGAGE_INTRO","How much can I borrow? Do a quick check.");
DEFINE("_EZMORTGAGE_AMOUNT","Total Monthly Income (after tax)");
DEFINE("_EZMORTGAGE_CURRENCY","$");
DEFINE("_EZMORTGAGE_REPAY","Approximate Borrowing Capacity");
DEFINE("_EZMORTGAGE_CALC","Calculate");
DEFINE("_EZMORTGAGE_CLEAR","Clear");


?>